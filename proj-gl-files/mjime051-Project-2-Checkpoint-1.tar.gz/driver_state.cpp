#include "driver_state.h"
#include <cstring>

driver_state::driver_state()
{
}

driver_state::~driver_state()
{
    delete [] image_color;
    delete [] image_depth;
}

// This function should allocate and initialize the arrays that store color and
// depth.  This is not done during the constructor since the width and height
// are not known when this class is constructed.
void initialize_render(driver_state& state, int width, int height)
{
    state.image_width=width;
    state.image_height=height;
    state.image_color = new pixel[width*height];
    state.image_depth=0;

	for (int i = 0; i < width*height; i++)
	{
		state.image_color[i] = make_pixel(0, 0, 0);
	}
	//TODO, will get back to image_depth

}

// This function will be called to render the data that has been stored in this class.
// Valid values of type are:
//   render_type::triangle - Each group of three vertices corresponds to a triangle.
//   render_type::indexed -  Each group of three indices in index_data corresponds
//                           to a triangle.  These numbers are indices into vertex_data.
//   render_type::fan -      The vertices are to be interpreted as a triangle fan.
//   render_type::strip -    The vertices are to be interpreted as a triangle strip.
void render(driver_state& state, render_type type)
{
	//I should declare this in triangle case but gives me errors about jump to case label, will come back to that once I figure out the issue
	int triangles;
	int currVertex = 0;

	data_geometry * dataGeoArr = new data_geometry[3];
	data_vertex dataVertex;
	switch (type) {
	case render_type::triangle:
		//This gives us the number of trangles
		triangles = state.num_vertices / 3;
		//for each triangle we have to call rasterize triangle but we need to fill dataGeoArr for each individual triangle
		for (int i = 0; i < triangles; i++) {
			//the data for each data_geometry in the array points to the first float of each vertex. 
			//Increment by state.floats_per_vertex to get to the next set of data for the next vertex
			for (int j = 0; j < 3; j++) {
				dataGeoArr[j].data = state.vertex_data + currVertex;
				currVertex += state.floats_per_vertex;
			}
			//now call vertex shader for our data_vertex using the array of data_geometry and the states uniform data
			for (int k = 0; k < 3; k++) {
				dataVertex.data = dataGeoArr[k].data;
				state.vertex_shader(dataVertex, dataGeoArr[k], state.uniform_data);
			}
			//finally call rasterize triangle on our dataGeoArr. Dont like how this looks 
			//but need to cast it to this for rasterize_triangle to work
			rasterize_triangle(state, (const data_geometry **)(&dataGeoArr));
		}
		break;

	case render_type::indexed:
		//TODO
		break;

	case render_type::fan:
		//TODO
		break;

	case render_type::strip:
		//TODO
		break;

	default:
		break;
	}
}


// This function clips a triangle (defined by the three vertices in the "in" array).
// It will be called recursively, once for each clipping face (face=0, 1, ..., 5) to
// clip against each of the clipping faces in turn.  When face=6, clip_triangle should
// simply pass the call on to rasterize_triangle.
void clip_triangle(driver_state& state, const data_geometry* in[3],int face)
{
    if(face==6)
    {
        rasterize_triangle(state, in);
        return;
    }
    //std::cout<<"TODO: implement clipping. (The current code passes the triangle through without clipping them.)"<<std::endl;
    clip_triangle(state,in,face+1);
}

// Rasterize the triangle defined by the three vertices in the "in" array.  This
// function is responsible for rasterization, interpolation of data to
// fragments, calling the fragment shader, and z-buffering.
void rasterize_triangle(driver_state& state, const data_geometry* in[3])
{
	//represents x and y pixel coordinates for the vertices of the triangle. ex. Vertex A is at x[0], y[0]
	int x[3];
	int y[3];
	//These are the weights in the slides. we technically only need to find two of the bary coords
	//and then just do 1-alpha-beta or whichever two you find to get the last one
	//Work with floats since that is the data type that everything else is
	float k0[3];
	float k1[3];
	float k2[3];
	//Need total area of the triangle to get bary coords
	float wholeTriArea;
	float baryCoords[3];

	// Find the pixel coords and put them into x[] and y[]

	for (int iter = 0; iter < 3; iter++) {
		x[iter] = (int)(state.image_width / 2.0 * (*in)[iter].gl_Position[0] + (state.image_width / 2.0 - .5));
		y[iter] = (int)(state.image_height / 2.0 * (*in)[iter].gl_Position[1] + (state.image_height / 2.0 - .5));
	}
	//All of these calculations are taken from class notes. If you need help then look at those or a tutorial on triangle rasterization
	wholeTriArea = .5 * ((x[1] * y[2] - x[2] * y[1]) - (x[0] * y[2] - x[2] * y[0]) - (x[0] * y[1] - x[1] * y[0]));
	//Just for reference, Vertex A is x[0], y[0]; Vertex B is x[1], y[1]; and Vertex C is x[2], y[2]
	k0[0] = x[1] * y[2] - x[2] * y[1];
	k1[0] = y[1] - y[2];
	k2[0] = x[2] - x[1];

	k0[1] = x[2] * y[0] - x[0] * y[2];
	k1[1] = y[2] - y[0];
	k2[1] = x[0] - x[2];

	k0[2] = x[0] * y[1] - x[1] * y[0];
	k1[2] = y[0] - y[1];
	k2[2] = x[1] - x[0];

	for (int i = 0; i < state.image_height; i++) {
		for (int j = 0; j < state.image_width; j++) {
			// Calculate bary coords
			for (int vert = 0; vert < 3; vert++) {
				baryCoords[vert] = .5 * (k0[vert] + (k1[vert] * j) + (k2[vert] * i)) / wholeTriArea;
			}

			bool baryCheck = true;
			//checking barycentric coords to make sure they are non negative. If they are negative then dont set the image color
			//optimized to only check greater than 0, see slides for why we can do this
			if (baryCoords[0] < 0 || baryCoords[1] < 0 || baryCoords[2] < 0)
			{
				baryCheck = false;
			}
			//If all the bary coords are valid then set the image_color to white for now
			if (baryCheck) {
				state.image_color[j + i * state.image_width] = make_pixel(255, 255, 255);
			}
		}
	}
}

